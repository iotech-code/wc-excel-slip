
![plugin logo](https://iotech.co.th/wp-content/uploads/2017/admin-icon.png) 
**WC Excel Slip**
------------
Wordpress plugin written by [In and Out Technology Company](https://iotech.co.th)
This plugin will generate output file as .xls format.
You can edit your own template by clone the */templates/default* folder to new folder and change design in *invoice.xls* file.

**Screenshot**
![slip output](https://iotech.co.th/wp-content/uploads/2017/Screen%20Shot%202560-11-23%20at%2006.40.34.png)

![Setting screen](https://iotech.co.th/wp-content/uploads/2017/Screen%20Shot%202560-11-23%20at%2006.41.22.png)

**Warning**
 - This plugin is require WooCommerce installed.

**Contribute**
Contributions are welcome you can fork this repository to your repository.

**Any question for developer**
Email to: [developer@iotech.co.th](developer@iotech.co.th)